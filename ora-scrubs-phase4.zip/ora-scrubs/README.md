# ORA — Medical Scrubber

Bilingual (Arabic/English) premium website for custom medical scrubs.

## Stack

Next.js 14 (App Router) · TypeScript · Tailwind CSS · next-intl

## Getting started

This project was built without network access in the build sandbox, so
dependencies are declared in `package.json` but not installed. On your
machine:

```bash
npm install
npm run dev
```

Then visit `http://localhost:3000` — it will redirect to `/en` or `/ar`
depending on your browser's language.

**Verification note:** the Google Fonts exports in `lib/fonts.ts`
(`Cormorant`, `Amiri`, `IBM_Plex_Sans`, `IBM_Plex_Sans_Arabic`) were
written against documented `next/font/google` naming conventions but
could not be build-tested in this sandbox. Run `npm run dev` and check
for font-loading errors as your first step — if an export name is
slightly off, `next/font/google`'s error message names the correct
export directly.

## Project structure

```
app/
  [locale]/
    layout.tsx              # root layout: <html dir/lang>, fonts, header/footer, localized metadata
    page.tsx                # home (placeholder using design-system primitives)
    order/page.tsx           # order form (placeholder)
    order/confirmation/page.tsx
    contact/page.tsx         # (placeholder)
  api/
    order/route.ts           # stub proxy to future Apps Script endpoint
  globals.css                 # design tokens (CSS custom properties)
components/
  layout/                     # Header, Footer, LanguageSwitcher
  ui/                          # Button, TextField, Divider, Section/Container
lib/
  i18n/                        # locale config, next-intl request config, navigation helpers
  fonts.ts                     # next/font setup, EN/AR pairing
  constants.ts                 # config-driven option lists (materials, shapes, payment methods)
  cn.ts                         # small classname utility
messages/
  en.json / ar.json             # translation strings (kept in sync key-for-key)
public/assets/
  logo/                         # official ORA logo
  products/                     # real product photography goes here later
types/
  order.ts                      # shared order data shapes
middleware.ts                   # locale detection + URL prefixing
tailwind.config.ts               # theme wired to CSS variable tokens
```

## Design tokens (Phase 2)

All defined in `app/globals.css`. See the comment block at the top of
that file for full provenance notes. Summary:

**Color**
- Gold (`--color-gold-light` / `--color-gold` / `--color-gold-deep` / `--color-gold-shadow`) — pixel-sampled directly from the official logo via k-means clustering, confirmed with an exhaustive full-image scan.
- Cream (`--color-cream` / `--color-cream-soft` / `--color-cream-white`) — the logo's own background tone, with one extra neutral lift for card/surface use.
- **No navy** — confirmed absent from the logo by exhaustive pixel scan (twice). Palette is gold + cream only per client decision. A navy-inclusive asset can be incorporated later if provided.
- Ink (`--color-ink` and muted/faint variants) — **not a brand color**, a functional near-black neutral needed for text contrast against the cream background. Flagged for approval, not a silent assumption.
- Border tokens (`--color-border`, `--color-border-gold`) — hairline dividers, not heavy card borders.

**Typography**
- Display: Cormorant (EN) / Amiri (AR) — both refined serifs with the same "editorial, bookish" register, echoing the logo's own thin-stroke serif wordmark.
- Body: IBM Plex Sans (EN) / IBM Plex Sans Arabic (AR) — designed as siblings in the same type family for maximum EN/AR coherence.
- Switches automatically via `[dir="rtl"]` in `globals.css` — no duplicated layout or component logic.

**Spacing / radius / shadow / motion**
- Spacing scale: `--space-3xs` through `--space-3xl`, generous editorial rhythm rather than dense SaaS spacing.
- Radius: near-square (`--radius-sm: 2px`, `--radius-md: 3px`) — deliberately restrained.
- Shadow: near-imperceptible (`--shadow-sm`, `--shadow-md`); hairline borders preferred over shadow for elevation.
- Motion: short, purposeful durations (`--duration-fast`, `--duration-base`); `prefers-reduced-motion` respected globally.

## Reusable primitives

- `Button` (`components/ui/Button.tsx`) — primary/secondary/ghost variants, near-square radius, sentence-case labels.
- `TextField` (`components/ui/TextField.tsx`) — hairline underline style (not boxed), numeric-field LTR isolation for measurements.
- `Divider` (`components/ui/Divider.tsx`) — plain hairline or ornamented (small centered mark echoing the logo's star accents), for use between major sections only.
- `Section` / `Container` (`components/ui/Section.tsx`) — consistent spacing rhythm and max-width wrapper, logical properties so it behaves identically in RTL/LTR.

## Phase 3 — Homepage

Full homepage built at `/[locale]` from `components/home/*`: Hero, ValueSection,
ShowcaseSection, CustomizationSection, ProcessSection, FinalCta. Header now
includes a responsive desktop nav + CTA and a hand-rolled accessible mobile
menu (`components/layout/MobileNav.tsx`). Footer expanded with nav links and
a contact placeholder.

**No real product photography exists in the project yet.** The hero and
showcase sections use `components/ui/PlaceholderArt.tsx` — an original,
independently-drawn abstract linework motif (not derived from or modifying
the logo file). Swap it for `next/image` calls once real photography is
provided; the surrounding layout/grid code doesn't need to change.

Official brand name is now confirmed: **ORA** (English) / **أورا** (Arabic).
The tagline ("Medical Scrubber" / "الزي الطبي") has been translated as
reasonable descriptive copy, not treated as fixed brand identity — flag if
you'd prefer the Latin tagline preserved on Arabic pages instead.

## Phase 4 — Order Form

Full order form UI at `/[locale]/order`, built from `components/order/*`:
`OrderForm` (state + validation orchestrator, no backend call yet),
`CustomerInfoSection`, `MeasurementsSection`, `ScrubCustomizationSection`,
`PaymentSection`, plus reusable `FormSection` (numbered section wrapper)
and `FileUploadField` (accessible upload with previews/removal, immediate
client-side type/size rejection).

Validation lives in `lib/validation/order.ts` (Zod schema) and
`lib/validation/fileConstraints.ts` (shared file type/size limits used by
both the schema and the upload UI, so they can't drift out of sync).
Raw controlled-input form state types live in `lib/order/formState.ts`,
kept separate from the Zod-validated/coerced types so numeric inputs can
stay as plain strings until submit.

**No backend call exists yet.** Submit runs the full Zod schema
client-side; on success it shows an inline notice ("backend submission
will be connected in a later phase") rather than sending anything
anywhere. The validated, typed result (`ValidatedOrder`) is exactly the
shape the future Apps Script integration will consume.

## What's intentionally not built yet

- Apps Script / Sheets / Drive integration (proxy route is still a 501 stub; order form does not call it)
- Material type and scrub shape fixed-option lists (`lib/constants.ts` — empty; the order form's "shape" field is free-text for now, see Phase 4 report)
- Real contact info, pricing, and payment account details
- Real product photography (placeholder art in Phase 3 sections)
