'use client';

import { useRef, useState, type FormEvent } from 'react';
import { useTranslations } from 'next-intl';
import { buttonVariants } from '@/components/ui/Button';
import { CustomerInfoSection } from './CustomerInfoSection';
import { MeasurementsSection } from './MeasurementsSection';
import { ScrubCustomizationSection } from './ScrubCustomizationSection';
import { PaymentSection } from './PaymentSection';
import {
  createInitialOrderFormState,
  type RawOrderFormState,
} from '@/lib/order/formState';
import { orderFormSchema, flattenZodErrors } from '@/lib/validation/order';

type SubmitState = 'idle' | 'invalid' | 'ready';

/**
 * Owns all form state and validation. No network call exists yet —
 * `handleSubmit` runs the same Zod schema that will eventually gate the
 * real Apps Script submission, so wiring up the backend later is a
 * matter of replacing the `setSubmitState('ready')` branch with an
 * actual request using this same validated, typed data.
 */
export function OrderForm() {
  const t = useTranslations('orderForm');
  const [values, setValues] = useState<RawOrderFormState>(
    createInitialOrderFormState
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitState, setSubmitState] = useState<SubmitState>('idle');
  const formTopRef = useRef<HTMLDivElement>(null);

  function updateCustomer(field: keyof RawOrderFormState['customer'], value: string) {
    setValues((prev) => ({
      ...prev,
      customer: { ...prev.customer, [field]: value },
    }));
  }

  function updateMeasurement(
    field: keyof Omit<RawOrderFormState['measurements'], 'referencePhotos'>,
    value: string
  ) {
    setValues((prev) => ({
      ...prev,
      measurements: { ...prev.measurements, [field]: value },
    }));
  }

  function updateReferencePhotos(files: File[]) {
    setValues((prev) => ({
      ...prev,
      measurements: { ...prev.measurements, referencePhotos: files },
    }));
  }

  function updateCustomizationText(
    field: 'shape' | 'colorDescription' | 'additionalDetails',
    value: string
  ) {
    setValues((prev) => ({
      ...prev,
      customization: { ...prev.customization, [field]: value },
    }));
  }

  function updateColorImage(file: File | null) {
    setValues((prev) => ({
      ...prev,
      customization: { ...prev.customization, colorReferenceImage: file },
    }));
  }

  function updateDesignImages(files: File[]) {
    setValues((prev) => ({
      ...prev,
      customization: { ...prev.customization, designReferenceImages: files },
    }));
  }

  function updatePaymentMethod(method: string) {
    setValues((prev) => ({
      ...prev,
      payment: { ...prev.payment, method: method as RawOrderFormState['payment']['method'] },
    }));
  }

  function updateScreenshot(file: File | null) {
    setValues((prev) => ({
      ...prev,
      payment: { ...prev.payment, screenshot: file },
    }));
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();

    const result = orderFormSchema.safeParse(values);

    if (!result.success) {
      setErrors(flattenZodErrors(result.error));
      setSubmitState('invalid');
      formTopRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    setErrors({});
    setSubmitState('ready');
    // Backend submission (Apps Script) is intentionally not implemented
    // yet — see component doc comment above.
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div ref={formTopRef} />

      {submitState === 'invalid' && (
        <p
          role="alert"
          className="mb-8 border border-gold-shadow bg-cream px-4 py-3 text-sm text-gold-shadow"
        >
          {t('submit.validationSummary')}
        </p>
      )}

      {submitState === 'ready' && (
        <div
          role="status"
          className="mb-8 border border-gold bg-cream px-4 py-4 text-sm text-ink"
        >
          <p className="font-medium">{t('submit.successHeading')}</p>
          <p className="mt-1 text-ink-muted">{t('submit.successBody')}</p>
        </div>
      )}

      <CustomerInfoSection
        values={values.customer}
        errors={errors}
        onChange={updateCustomer}
      />

      <MeasurementsSection
        values={values.measurements}
        errors={errors}
        onChange={updateMeasurement}
        onPhotosChange={updateReferencePhotos}
      />

      <ScrubCustomizationSection
        values={values.customization}
        errors={errors}
        onTextChange={updateCustomizationText}
        onColorImageChange={updateColorImage}
        onDesignImagesChange={updateDesignImages}
      />

      <PaymentSection
        values={values.payment}
        errors={errors}
        onMethodChange={updatePaymentMethod}
        onScreenshotChange={updateScreenshot}
      />

      <div className="border-t border-border pt-10">
        <button type="submit" className={buttonVariants('primary')}>
          {t('submit.button')}
        </button>
        <p className="mt-4 max-w-prose text-xs text-ink-faint">
          {t('submit.backendNotice')}
        </p>
      </div>
    </form>
  );
}
