import { useTranslations } from 'next-intl';
import { RadioGroup } from '@/components/ui/RadioGroup';
import { FileUploadField } from './FileUploadField';
import { FormSection } from './FormSection';
import { PAYMENT_METHODS } from '@/lib/constants';
import type { RawPaymentInfo } from '@/lib/order/formState';

interface PaymentSectionProps {
  values: RawPaymentInfo;
  errors: Record<string, string>;
  onMethodChange: (method: string) => void;
  onScreenshotChange: (file: File | null) => void;
}

export function PaymentSection({
  values,
  errors,
  onMethodChange,
  onScreenshotChange,
}: PaymentSectionProps) {
  const t = useTranslations('orderForm');
  const tf = useTranslations('orderForm.fields');
  const tu = useTranslations('orderForm.upload');

  const options = PAYMENT_METHODS.map((method) => ({
    value: method.value,
    label: method.value === 'vodafone_cash' ? tf('vodafoneCash') : tf('instapay'),
  }));

  return (
    <FormSection
      index="04"
      title={t('sections.payment.title')}
      description={t('sections.payment.description')}
    >
      <RadioGroup
        legend={tf('paymentMethod.legend')}
        name="payment-method"
        options={options}
        value={values.method}
        onChange={onMethodChange}
        error={errors['payment.method']}
      />

      <FileUploadField
        label={tf('screenshot.label')}
        hint={tf('screenshot.hint')}
        error={errors['payment.screenshot']}
        files={values.screenshot ? [values.screenshot] : []}
        onChange={(files) => onScreenshotChange(files[0] ?? null)}
        i18n={{
          addFiles: '',
          remove: (fileName) => tu('remove', { fileName }),
          tooLarge: (fileName) => tu('tooLarge', { fileName }),
          wrongType: (fileName) => tu('wrongType', { fileName }),
          tooMany: tu('tooMany', { max: 1 }),
        }}
      />
    </FormSection>
  );
}
