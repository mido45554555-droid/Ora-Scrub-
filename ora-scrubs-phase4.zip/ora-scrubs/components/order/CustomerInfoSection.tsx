import { useTranslations } from 'next-intl';
import { TextField } from '@/components/ui/TextField';
import { FormSection } from './FormSection';
import type { RawCustomerInfo } from '@/lib/order/formState';

interface CustomerInfoSectionProps {
  values: RawCustomerInfo;
  errors: Record<string, string>;
  onChange: (field: keyof RawCustomerInfo, value: string) => void;
}

export function CustomerInfoSection({
  values,
  errors,
  onChange,
}: CustomerInfoSectionProps) {
  const t = useTranslations('orderForm');
  const tf = useTranslations('orderForm.fields');

  return (
    <FormSection
      index="01"
      title={t('sections.customer.title')}
      description={t('sections.customer.description')}
    >
      <TextField
        label={tf('fullName.label')}
        value={values.fullName}
        onChange={(e) => onChange('fullName', e.target.value)}
        error={errors['customer.fullName']}
        autoComplete="name"
        required
      />
      <TextField
        label={tf('mobileNumber.label')}
        hint={tf('mobileNumber.hint')}
        value={values.mobileNumber}
        onChange={(e) => onChange('mobileNumber', e.target.value)}
        error={errors['customer.mobileNumber']}
        type="tel"
        numeric
        autoComplete="tel"
        required
      />
      <TextField
        label={tf('address.label')}
        hint={tf('address.hint')}
        value={values.address}
        onChange={(e) => onChange('address', e.target.value)}
        error={errors['customer.address']}
        autoComplete="street-address"
        required
      />
      <div className="grid grid-cols-2 gap-6">
        <TextField
          label={tf('height.label')}
          value={values.heightCm}
          onChange={(e) => onChange('heightCm', e.target.value)}
          error={errors['customer.heightCm']}
          type="number"
          inputMode="decimal"
          numeric
          required
        />
        <TextField
          label={tf('weight.label')}
          value={values.weightKg}
          onChange={(e) => onChange('weightKg', e.target.value)}
          error={errors['customer.weightKg']}
          type="number"
          inputMode="decimal"
          numeric
          required
        />
      </div>
    </FormSection>
  );
}
