import { useId } from 'react';
import { cn } from '@/lib/cn';

interface RadioOption {
  value: string;
  label: string;
}

interface RadioGroupProps {
  legend: string;
  name: string;
  options: RadioOption[];
  value: string;
  onChange: (value: string) => void;
  error?: string;
  className?: string;
}

/**
 * Uses native <input type="radio"> (full built-in keyboard support and
 * screen reader semantics) rather than a custom div-based widget, styled
 * minimally with `accent-color` so it picks up the brand gold without
 * losing native behavior.
 */
export function RadioGroup({
  legend,
  name,
  options,
  value,
  onChange,
  error,
  className,
}: RadioGroupProps) {
  const groupId = useId();
  const errorId = error ? `${groupId}-error` : undefined;

  return (
    <fieldset
      className={cn('flex flex-col gap-3', className)}
      aria-describedby={errorId}
      aria-invalid={Boolean(error)}
    >
      <legend className="text-xs font-medium tracking-wide text-ink-muted">
        {legend}
      </legend>
      <div className="flex flex-col gap-3 sm:flex-row sm:gap-8">
        {options.map((option) => {
          const inputId = `${groupId}-${option.value}`;
          return (
            <label
              key={option.value}
              htmlFor={inputId}
              className="flex cursor-pointer items-center gap-2 text-sm text-ink"
            >
              <input
                type="radio"
                id={inputId}
                name={name}
                value={option.value}
                checked={value === option.value}
                onChange={() => onChange(option.value)}
                className="h-4 w-4 accent-gold"
              />
              {option.label}
            </label>
          );
        })}
      </div>
      {error && (
        <p id={errorId} className="text-xs text-gold-shadow">
          {error}
        </p>
      )}
    </fieldset>
  );
}
