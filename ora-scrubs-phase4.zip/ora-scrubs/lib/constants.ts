/**
 * Config-driven option lists for the order form. Kept as data rather
 * than hardcoded in components, so populating real options later is a
 * data change, not a code change.
 */

export interface LocalizedOption {
  value: string;
  label: { en: string; ar: string };
}

/**
 * Material type choices — intentionally empty. The client will provide
 * the actual material list later; until then the field should render as
 * hidden or disabled in the order form (decide which when the form is
 * built), never with invented material names.
 */
export const MATERIAL_OPTIONS: LocalizedOption[] = [];

/**
 * Scrub shape/model choices — also pending. Not yet provided by the
 * client, so left empty rather than guessed.
 */
export const SCRUB_SHAPE_OPTIONS: LocalizedOption[] = [];

export const PAYMENT_METHODS: LocalizedOption[] = [
  { value: 'vodafone_cash', label: { en: 'Vodafone Cash', ar: 'فودافون كاش' } },
  { value: 'instapay', label: { en: 'InstaPay', ar: 'إنستاباي' } },
];
