import { useTranslations } from 'next-intl';
import { Section, Container } from '@/components/ui/Section';

export default function OrderConfirmationPage() {
  const t = useTranslations('orderConfirmation');
  const tPlaceholder = useTranslations('placeholderPage');

  return (
    <Section>
      <Container className="text-center">
        <h1 className="font-display text-3xl text-ink">{t('title')}</h1>
        <p className="mt-4 text-ink-muted">{tPlaceholder('comingSoon')}</p>
      </Container>
    </Section>
  );
}
