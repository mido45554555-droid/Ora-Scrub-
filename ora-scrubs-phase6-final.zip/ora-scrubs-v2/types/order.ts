/**
 * Structural foundation only — field-level validation, optionality, and
 * the payment/upload shapes will be finalized when the order form is
 * built (not this phase). Kept here so both the form and the future
 * Apps Script API client share one contract instead of drifting apart.
 */

export interface CustomerInfo {
  fullName: string;
  mobileNumber: string;
  address: string;
  heightCm: number;
  weightKg: number;
}

export interface Measurements {
  armLength: number;
  shoulderCircumference: number;
  blouseLength: number;
  trouserLength: number;
  hipCircumference: number;
  waistCircumference: number;
  chestCircumference: number;
  thighCircumference: number;
  /** Optional tailor-taken measurement photos. */
  referencePhotos?: File[];
}

export interface ScrubCustomization {
  shape: string;
  /** Free-form color request — never a fixed enum, per the brief. */
  colorDescription: string;
  /** Required reference image showing the desired color. */
  colorReferenceImage: File;
  /** Populated once material options are finalized (see lib/constants.ts). */
  materialType?: string;
  additionalDetails?: string;
  /** Up to 4 images. */
  designReferenceImages: File[];
}

export type PaymentMethod = 'vodafone_cash' | 'instapay';

export interface PaymentInfo {
  method: PaymentMethod;
  /** Kept separate from design/reference images in both the UI and the
   * eventual Drive folder structure. */
  screenshot: File;
}

export interface OrderPayload {
  customer: CustomerInfo;
  measurements: Measurements;
  customization: ScrubCustomization;
  payment: PaymentInfo;
}

export interface OrderSubmissionResult {
  orderReference: string;
  status: 'success';
}
