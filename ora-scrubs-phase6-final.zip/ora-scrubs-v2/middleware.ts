import createMiddleware from 'next-intl/middleware';
import { locales, defaultLocale } from './lib/i18n/config';

export default createMiddleware({
  locales,
  defaultLocale,
  // The chosen locale persists via the standard NEXT_LOCALE cookie that
  // next-intl sets automatically, so a returning visitor lands back on
  // their last language rather than being re-detected every time.
  localeDetection: true,
});

export const config = {
  // Run on every path except static files, images, and API routes.
  matcher: ['/((?!api|_next|.*\\..*).*)'],
};
