/**
 * Generates a client-side-only order reference for display on the
 * confirmation page.
 *
 * IMPORTANT: this is a placeholder for pre-backend QA/testing of the
 * Home → Order → Confirmation flow only. It is NOT a secure or
 * reliable order identifier — it's generated in the browser, is
 * trivially guessable/collidable, and is never persisted anywhere.
 * Once the Apps Script integration exists, the real order reference
 * MUST be generated server-side (in Apps Script, at the point the row
 * is written to Sheets) and returned to the client in the submission
 * response — this function should be deleted at that point, not kept
 * as a fallback.
 */
export function generateClientOrderReference(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `ORA-${timestamp}-${random}`;
}
