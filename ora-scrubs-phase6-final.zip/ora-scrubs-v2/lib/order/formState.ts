import type { PaymentMethod } from '@/types/order';

/**
 * Shape of the actual controlled-input state. Numeric fields are kept
 * as strings here (what a controlled <input> naturally holds) and only
 * coerced to numbers at validation time via the Zod schema — keeping
 * two separate types (raw vs. validated) avoids fighting the input's
 * native string value on every keystroke.
 */
export interface RawCustomerInfo {
  fullName: string;
  mobileNumber: string;
  address: string;
  heightCm: string;
  weightKg: string;
}

export interface RawMeasurements {
  armLength: string;
  shoulderCircumference: string;
  blouseLength: string;
  trouserLength: string;
  hipCircumference: string;
  waistCircumference: string;
  chestCircumference: string;
  thighCircumference: string;
  referencePhotos: File[];
}

export interface RawScrubCustomization {
  shape: string;
  colorDescription: string;
  colorReferenceImage: File | null;
  additionalDetails: string;
  designReferenceImages: File[];
}

export interface RawPaymentInfo {
  method: PaymentMethod | '';
  screenshot: File | null;
}

export interface RawOrderFormState {
  customer: RawCustomerInfo;
  measurements: RawMeasurements;
  customization: RawScrubCustomization;
  payment: RawPaymentInfo;
}

export function createInitialOrderFormState(): RawOrderFormState {
  return {
    customer: {
      fullName: '',
      mobileNumber: '',
      address: '',
      heightCm: '',
      weightKg: '',
    },
    measurements: {
      armLength: '',
      shoulderCircumference: '',
      blouseLength: '',
      trouserLength: '',
      hipCircumference: '',
      waistCircumference: '',
      chestCircumference: '',
      thighCircumference: '',
      referencePhotos: [],
    },
    customization: {
      shape: '',
      colorDescription: '',
      colorReferenceImage: null,
      additionalDetails: '',
      designReferenceImages: [],
    },
    payment: {
      method: '',
      screenshot: null,
    },
  };
}

export type OrderFormSection = keyof RawOrderFormState;
