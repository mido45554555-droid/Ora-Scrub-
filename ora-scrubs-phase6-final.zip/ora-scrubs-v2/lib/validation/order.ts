import { z } from 'zod';
import {
  ACCEPTED_IMAGE_TYPES,
  MAX_FILE_SIZE_BYTES,
  MAX_FILE_SIZE_MB,
  MAX_GALLERY_FILES,
} from './fileConstraints';

/**
 * Validates a File instance directly (type/size), rather than only a
 * file *list*. `z.custom` defers the `instanceof File` check until
 * validation actually runs (at submit time, in the browser) rather
 * than at schema-definition time, so this module is safe to import
 * even though the component using it is server-rendered once on the
 * initial request — the `File` global is never touched until a real
 * submit/validate call happens client-side.
 */
function requiredFileSchema(requiredMessage: string) {
  return z
    .custom<File>((val) => val instanceof File, { message: requiredMessage })
    .refine((file) => ACCEPTED_IMAGE_TYPES.includes(file.type), {
      message: 'Please upload a JPG, PNG, or WEBP image.',
    })
    .refine((file) => file.size <= MAX_FILE_SIZE_BYTES, {
      message: `File must be smaller than ${MAX_FILE_SIZE_MB}MB.`,
    });
}

const optionalImageArraySchema = z
  .array(requiredFileSchema('Invalid file.'))
  .max(MAX_GALLERY_FILES, `You can upload up to ${MAX_GALLERY_FILES} images.`);

/** Empty-string-safe number field: coerces "" to "required" rather
 * than to 0 (which `z.coerce.number()` would otherwise do, since
 * `Number("")` is 0, not NaN). */
function measurementField(label: string, min: number, max: number) {
  return z.preprocess(
    (val) => (val === '' || val === null || val === undefined ? undefined : val),
    z
      .coerce.number({
        required_error: `${label} is required.`,
        invalid_type_error: `${label} must be a number.`,
      })
      .min(min, `${label} must be at least ${min}.`)
      .max(max, `${label} must be at most ${max}.`)
  );
}

export const customerInfoSchema = z.object({
  fullName: z.string().trim().min(2, 'Please enter your full name.'),
  mobileNumber: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s]{8,20}$/, 'Please enter a valid mobile number.'),
  address: z.string().trim().min(10, 'Please provide a detailed address.'),
  heightCm: measurementField('Height', 50, 250),
  weightKg: measurementField('Weight', 20, 300),
});

export const measurementsSchema = z.object({
  armLength: measurementField('Arm length', 10, 120),
  shoulderCircumference: measurementField('Shoulder circumference', 10, 100),
  blouseLength: measurementField('Blouse length', 10, 150),
  trouserLength: measurementField('Trouser length', 10, 150),
  hipCircumference: measurementField('Hip circumference', 20, 200),
  waistCircumference: measurementField('Waist circumference', 20, 200),
  chestCircumference: measurementField('Chest circumference', 20, 200),
  thighCircumference: measurementField('Thigh circumference', 10, 150),
  referencePhotos: optionalImageArraySchema,
});

export const scrubCustomizationSchema = z.object({
  shape: z.string().trim().min(2, 'Please describe the shape or model you want.'),
  colorDescription: z.string().trim().optional(),
  colorReferenceImage: requiredFileSchema('Please upload a color reference image.'),
  additionalDetails: z.string().trim().optional(),
  designReferenceImages: optionalImageArraySchema,
});

export const paymentInfoSchema = z.object({
  method: z.enum(['vodafone_cash', 'instapay'], {
    errorMap: () => ({ message: 'Please select a payment method.' }),
  }),
  screenshot: requiredFileSchema('Please upload your payment screenshot.'),
});

export const orderFormSchema = z.object({
  customer: customerInfoSchema,
  measurements: measurementsSchema,
  customization: scrubCustomizationSchema,
  payment: paymentInfoSchema,
});

export type ValidatedOrder = z.infer<typeof orderFormSchema>;

/**
 * Flattens Zod issues into a dotted-path -> message map
 * (e.g. "customer.fullName") matching the raw form state's field
 * paths, so a section component can look up its own errors directly.
 */
export function flattenZodErrors(error: z.ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const issue of error.issues) {
    const path = issue.path.join('.');
    if (!errors[path]) {
      errors[path] = issue.message;
    }
  }
  return errors;
}
