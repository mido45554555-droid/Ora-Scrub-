import { useTranslations } from 'next-intl';
import { TextField } from '@/components/ui/TextField';
import { FileUploadField } from './FileUploadField';
import { FormSection } from './FormSection';
import { MAX_GALLERY_FILES } from '@/lib/validation/fileConstraints';
import type { RawMeasurements } from '@/lib/order/formState';

type MeasurementNumericField = keyof Omit<RawMeasurements, 'referencePhotos'>;

interface MeasurementsSectionProps {
  values: RawMeasurements;
  errors: Record<string, string>;
  onChange: (field: MeasurementNumericField, value: string) => void;
  onPhotosChange: (files: File[]) => void;
}

const NUMERIC_FIELDS: MeasurementNumericField[] = [
  'armLength',
  'shoulderCircumference',
  'blouseLength',
  'trouserLength',
  'hipCircumference',
  'waistCircumference',
  'chestCircumference',
  'thighCircumference',
];

export function MeasurementsSection({
  values,
  errors,
  onChange,
  onPhotosChange,
}: MeasurementsSectionProps) {
  const t = useTranslations('orderForm');
  const tf = useTranslations('orderForm.fields');
  const tu = useTranslations('orderForm.upload');

  return (
    <FormSection
      id="section-measurements"
      index="02"
      title={t('sections.measurements.title')}
      description={t('sections.measurements.description')}
    >
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        {NUMERIC_FIELDS.map((field) => (
          <TextField
            key={field}
            label={tf(`${String(field)}.label`)}
            value={values[field]}
            onChange={(e) => onChange(field, e.target.value)}
            error={errors[`measurements.${String(field)}`]}
            type="number"
            inputMode="decimal"
            numeric
            required
          />
        ))}
      </div>

      <FileUploadField
        label={tf('referencePhotos.label')}
        hint={tf('referencePhotos.hint')}
        optionalLabel={t('optionalLabel')}
        error={errors['measurements.referencePhotos']}
        multiple
        maxFiles={MAX_GALLERY_FILES}
        files={values.referencePhotos}
        onChange={onPhotosChange}
        i18n={{
          addFiles: '',
          remove: (fileName) => tu('remove', { fileName }),
          tooLarge: (fileName) => tu('tooLarge', { fileName }),
          wrongType: (fileName) => tu('wrongType', { fileName }),
          tooMany: tu('tooMany', { max: MAX_GALLERY_FILES }),
        }}
      />
    </FormSection>
  );
}
