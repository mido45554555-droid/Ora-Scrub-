'use client';

import { useRef, useState, type FormEvent } from 'react';
import { useTranslations } from 'next-intl';
import { useRouter } from '@/lib/i18n/navigation';
import { buttonVariants } from '@/components/ui/Button';
import { CustomerInfoSection } from './CustomerInfoSection';
import { MeasurementsSection } from './MeasurementsSection';
import { ScrubCustomizationSection } from './ScrubCustomizationSection';
import { PaymentSection } from './PaymentSection';
import { OrderBasket } from './OrderBasket';
import {
  createInitialOrderFormState,
  type RawOrderFormState,
} from '@/lib/order/formState';
import { generateClientOrderReference } from '@/lib/order/reference';
import { orderFormSchema, flattenZodErrors } from '@/lib/validation/order';

type SubmitState = 'idle' | 'invalid' | 'submitting';

/**
 * Owns all form state and validation. No network call exists yet —
 * `handleSubmit` runs the same Zod schema that will eventually gate the
 * real Apps Script submission, then navigates to the confirmation page
 * with a client-side placeholder reference (see lib/order/reference.ts).
 * Wiring up the real backend later means replacing that placeholder
 * generation with an actual request, using this same validated, typed
 * data, and using the reference the server returns instead.
 */
export function OrderForm() {
  const t = useTranslations('orderForm');
  const router = useRouter();
  const [values, setValues] = useState<RawOrderFormState>(
    createInitialOrderFormState
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitState, setSubmitState] = useState<SubmitState>('idle');
  const formTopRef = useRef<HTMLDivElement>(null);

  function updateCustomer(field: keyof RawOrderFormState['customer'], value: string) {
    setValues((prev) => ({
      ...prev,
      customer: { ...prev.customer, [field]: value },
    }));
  }

  function updateMeasurement(
    field: keyof Omit<RawOrderFormState['measurements'], 'referencePhotos'>,
    value: string
  ) {
    setValues((prev) => ({
      ...prev,
      measurements: { ...prev.measurements, [field]: value },
    }));
  }

  function updateReferencePhotos(files: File[]) {
    setValues((prev) => ({
      ...prev,
      measurements: { ...prev.measurements, referencePhotos: files },
    }));
  }

  function updateCustomizationText(
    field: 'shape' | 'colorDescription' | 'additionalDetails',
    value: string
  ) {
    setValues((prev) => ({
      ...prev,
      customization: { ...prev.customization, [field]: value },
    }));
  }

  function updateColorImage(file: File | null) {
    setValues((prev) => ({
      ...prev,
      customization: { ...prev.customization, colorReferenceImage: file },
    }));
  }

  function updateDesignImages(files: File[]) {
    setValues((prev) => ({
      ...prev,
      customization: { ...prev.customization, designReferenceImages: files },
    }));
  }

  function updatePaymentMethod(method: string) {
    setValues((prev) => ({
      ...prev,
      payment: { ...prev.payment, method: method as RawOrderFormState['payment']['method'] },
    }));
  }

  function updateScreenshot(file: File | null) {
    setValues((prev) => ({
      ...prev,
      payment: { ...prev.payment, screenshot: file },
    }));
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();

    const result = orderFormSchema.safeParse(values);

    if (!result.success) {
      setErrors(flattenZodErrors(result.error));
      setSubmitState('invalid');
      formTopRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    setErrors({});
    setSubmitState('submitting');
    // No backend call exists yet (see component doc comment above), so
    // there's nothing to await here. The reference below is a
    // client-side placeholder for testing the Home -> Order ->
    // Confirmation journey — see lib/order/reference.ts for why this
    // must be replaced with a server-generated reference once the
    // Apps Script integration exists.
    const reference = generateClientOrderReference();
    router.push(`/order/confirmation?ref=${encodeURIComponent(reference)}`);
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div ref={formTopRef} />

      {submitState === 'invalid' && (
        <p
          role="alert"
          className="mb-8 border border-gold-shadow bg-cream px-4 py-3 text-sm text-gold-shadow"
        >
          {t('submit.validationSummary')}
        </p>
      )}

      <CustomerInfoSection
        values={values.customer}
        errors={errors}
        onChange={updateCustomer}
      />

      <MeasurementsSection
        values={values.measurements}
        errors={errors}
        onChange={updateMeasurement}
        onPhotosChange={updateReferencePhotos}
      />

      <ScrubCustomizationSection
        values={values.customization}
        errors={errors}
        onTextChange={updateCustomizationText}
        onColorImageChange={updateColorImage}
        onDesignImagesChange={updateDesignImages}
      />

      <PaymentSection
        values={values.payment}
        errors={errors}
        onMethodChange={updatePaymentMethod}
        onScreenshotChange={updateScreenshot}
      />

      <div className="border-t border-border pt-10">
        <button
          type="submit"
          disabled={submitState === 'submitting'}
          className={buttonVariants('primary')}
        >
          {submitState === 'submitting' ? t('submit.submitting') : t('submit.button')}
        </button>
        <p className="mt-4 max-w-prose text-xs text-ink-faint">
          {t('submit.backendNotice')}
        </p>
      </div>

      <OrderBasket
        values={values}
        onColorImageChange={updateColorImage}
        onDesignImagesChange={updateDesignImages}
        onReferencePhotosChange={updateReferencePhotos}
        onPaymentMethodChange={updatePaymentMethod}
        onScreenshotChange={updateScreenshot}
      />
    </form>
  );
}
