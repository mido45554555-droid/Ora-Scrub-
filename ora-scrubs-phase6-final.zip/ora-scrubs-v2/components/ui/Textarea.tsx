import { type TextareaHTMLAttributes, forwardRef, useId } from 'react';
import { cn } from '@/lib/cn';

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
  hint?: string;
  optionalLabel?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, label, error, hint, optionalLabel, id, ...props }, ref) => {
    const generatedId = useId();
    const fieldId = id ?? generatedId;
    const hintId = hint ? `${fieldId}-hint` : undefined;
    const errorId = error ? `${fieldId}-error` : undefined;
    const describedBy = [hintId, errorId].filter(Boolean).join(' ') || undefined;

    return (
      <div className="flex flex-col gap-2">
        <label
          htmlFor={fieldId}
          className="flex items-baseline justify-between text-xs font-medium tracking-wide text-ink-muted"
        >
          <span>{label}</span>
          {optionalLabel && <span className="text-ink-faint">{optionalLabel}</span>}
        </label>
        {hint && (
          <p id={hintId} className="-mt-1 text-xs text-ink-faint">
            {hint}
          </p>
        )}
        <textarea
          ref={ref}
          id={fieldId}
          rows={3}
          className={cn(
            'resize-y border border-border bg-transparent p-3 text-ink outline-none transition-colors duration-base ease-standard placeholder:text-ink-faint focus:border-gold',
            error && 'border-gold-shadow',
            className
          )}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          {...props}
        />
        {error && (
          <p id={errorId} className="text-xs text-gold-shadow">
            {error}
          </p>
        )}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';
