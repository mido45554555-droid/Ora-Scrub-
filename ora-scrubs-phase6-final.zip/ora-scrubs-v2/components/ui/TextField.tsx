import { type InputHTMLAttributes, forwardRef, useId } from 'react';
import { cn } from '@/lib/cn';

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  /** Marks the field's value as always-LTR (e.g. measurements, phone
   * numbers) regardless of surrounding page direction. */
  numeric?: boolean;
  error?: string;
  hint?: string;
  /** Localized "Optional" label text — pass this in from the caller
   * (translated) rather than hardcoding English here. Omit for
   * required fields. */
  optionalLabel?: string;
}

/**
 * Hairline bottom-border style rather than a boxed/rounded input — fits
 * the editorial, non-SaaS direction. Label sits above in a small,
 * sentence-case (not all-caps) tracked label. Error and hint text are
 * both wired to the input via aria-describedby so assistive tech
 * announces them, and aria-invalid reflects error state.
 */
export const TextField = forwardRef<HTMLInputElement, TextFieldProps>(
  (
    { className, label, numeric, error, hint, optionalLabel, id, ...props },
    ref
  ) => {
    const generatedId = useId();
    const fieldId = id ?? generatedId;
    const hintId = hint ? `${fieldId}-hint` : undefined;
    const errorId = error ? `${fieldId}-error` : undefined;
    const describedBy = [hintId, errorId].filter(Boolean).join(' ') || undefined;

    return (
      <div className="flex flex-col gap-2">
        <label
          htmlFor={fieldId}
          className="flex items-baseline justify-between text-xs font-medium tracking-wide text-ink-muted"
        >
          <span>{label}</span>
          {optionalLabel && <span className="text-ink-faint">{optionalLabel}</span>}
        </label>
        {hint && (
          <p id={hintId} className="-mt-1 text-xs text-ink-faint">
            {hint}
          </p>
        )}
        <input
          ref={ref}
          id={fieldId}
          className={cn(
            'border-0 border-b border-border bg-transparent pb-2 text-ink outline-none transition-colors duration-base ease-standard placeholder:text-ink-faint focus:border-gold',
            numeric && 'numeric-field',
            error && 'border-gold-shadow',
            className
          )}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          {...props}
        />
        {error && (
          <p id={errorId} className="text-xs text-gold-shadow">
            {error}
          </p>
        )}
      </div>
    );
  }
);

TextField.displayName = 'TextField';
