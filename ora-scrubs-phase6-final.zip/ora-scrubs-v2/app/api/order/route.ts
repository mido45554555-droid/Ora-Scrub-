import { NextResponse } from 'next/server';

/**
 * Placeholder proxy route. Once the order form exists, this will forward
 * validated submissions to the Google Apps Script Web App endpoint
 * (configured via APPS_SCRIPT_ORDER_ENDPOINT, see .env.example) rather
 * than having the browser call Apps Script directly — see the Phase 1
 * report for why. No request handling logic yet; intentionally left as
 * a stub until the order form and validation schema are built.
 */
export async function POST() {
  return NextResponse.json(
    { error: 'Order submission is not implemented yet.' },
    { status: 501 }
  );
}
