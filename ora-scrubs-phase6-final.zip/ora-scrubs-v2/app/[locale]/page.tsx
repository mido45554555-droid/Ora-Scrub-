import { Hero } from '@/components/home/Hero';
import { ValueSection } from '@/components/home/ValueSection';
import { ShowcaseSection } from '@/components/home/ShowcaseSection';
import { CustomizationSection } from '@/components/home/CustomizationSection';
import { ProcessSection } from '@/components/home/ProcessSection';
import { FinalCta } from '@/components/home/FinalCta';

export default function HomePage() {
  return (
    <>
      <Hero />
      <ValueSection />
      <ShowcaseSection />
      <CustomizationSection />
      <ProcessSection />
      <FinalCta />
    </>
  );
}
